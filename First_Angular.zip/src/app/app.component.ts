import { componentFactoryName } from '@angular/compiler';
import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MyFirstApp';
  myName:String;    
  UserName:String;
  public gurl:string="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRtvsvhlGajOKsIqGbq71Yfl7qufZR2oyS0PA&usqp=CAU";
  public burl:string="https://media4.giphy.com/media/htXhWjo2545qII8JgZ/giphy-downsized-large.gif";
  ButtonEvent(event) { 
    alert('First Angular Project'); 
   } 
   values = '';
   msg='';
   selectedValue='';
   dvalue='';
   dropValue='';
   text='';
   onKey(event: any) { // without type info
     this.values += event.target.value + ' | ';
   }
   onKeyenter(event:any){
     this.msg+=event.target.value + '|';
   }
   welmsg(firstName, lastName) {
    alert('Welcome '+firstName.value+' '+ lastName.value)
  } 
  txtMeth(txt){
    console.log("Text Area content : "+txt.value)
  }
  dropMeth(dvalue){
    console.log("Selected Value : "+dvalue.value)
  }
  constructor(){
    setTimeout(()=>{
      this.gurl=this.burl;
      this.title="Brown Cony";
      console.log("First Angular Project!!");
    },10000);

  }
}
