export default class Employee{
    constructor(empId:number,empName:string,design:string){
        this.empId=empId;
        this.empName = empName;
        this.design=design;
    }
    empId:number;
    empName:string;
    design:string;
   
}