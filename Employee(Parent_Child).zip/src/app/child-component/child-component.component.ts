import { Component,Input, OnInit } from '@angular/core';
import Employee from '../Employee';

@Component({
  selector: 'app-child-component',
  templateUrl: './child-component.component.html',
  styleUrls: ['./child-component.component.css']
})
export class ChildComponentComponent implements OnInit {

  @Input()
  public empdet:Employee[]=[];
  constructor() { }

  ngOnInit(): void {
  }

}
