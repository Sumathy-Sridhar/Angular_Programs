import { Component } from '@angular/core';
import Employee from './Employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Newprj';
  myemp:Employee[]=[];
  constructor(){
    this.myemp=[
      {empId:1,empName:"Brown",design:"HR"},
      {empId:2,empName:"Cony",design:"Manager"},
      {empId:3,empName:"Peach",design:"Trainee"}
    ]
  }
}
