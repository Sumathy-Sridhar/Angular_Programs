import { Component } from '@angular/core';
import Employee from './Employee';
import Product from './Product';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Newprj';
  myemp:Employee[]=[];
  myprd:Product[]=[];

  CountriesList='';
  constructor(){
    this.myemp=[
      {empId:1,empName:"Brown",design:"HR"},
      {empId:2,empName:"Cony",design:"Manager"}
    ]
    this.myprd=[{pid:1,prdname:"Eyeliner",description:"Cosmetics",cost:30000,type:this.checkoddeven(1)},
    {pid:2,prdname:"NailPolish",description:"Accessories",cost:50,type:this.checkoddeven(2)},
    {pid:3,prdname:"Kurti",description:"Girls Wear",cost:2000,type:this.checkoddeven(3)},
    {pid:4,prdname:"Earring",description:"Cosmetics",cost:300,type:this.checkoddeven(4)}
  ]
} 

public handleaddprd(e:any){
  console.log(JSON.stringify(e))
  this.myprd.push(e);
  
  }
selectedCity(se:any)
{
  this.CountriesList = se.target.value;
}
checkoddeven(check:number){
  return check %2==0?"even":"odd";
}

}
