export default class Product {
    constructor(pid:number,prdname:string,description:string,cost:number, type:string){
        this.prdname = prdname;
        this.pid = pid;
        this.description=description;
        this.cost=cost;
        this.type=type;
    }
    pid:number;
    prdname:string="";
    description:string="";
    cost:number;
    type:string="";

}