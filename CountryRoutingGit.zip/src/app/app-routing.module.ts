import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IndiaContentComponent } from './components/india-content/india-content.component';
import { UkContentComponent } from './components/uk-content/uk-content.component';
import { UsaContentComponent } from './components/usa-content/usa-content.component';

const routes: Routes = [
  {path:'India',component:IndiaContentComponent},
  {path:'USA',component:UsaContentComponent},
  {path:'UK',component:UkContentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
