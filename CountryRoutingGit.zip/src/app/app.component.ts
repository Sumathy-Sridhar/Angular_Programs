import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CountryRouting';
  selval:string='';
  constructor(private Route:Router){}
  selectedCity(){
    console.log("Selected Country : " +this.selval);
    if(this.selval=='India'){
      this.Route.navigate(['India']);
    }
    else  if(this.selval=='USA'){
      this.Route.navigate(['USA']);
    }
    else  if(this.selval=='UK'){
      this.Route.navigate(['UK']);
    }
    else{
      this.Route.navigate(['India']);
    }
  }

}
