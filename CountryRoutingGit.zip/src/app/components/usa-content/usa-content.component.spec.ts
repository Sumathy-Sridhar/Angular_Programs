import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsaContentComponent } from './usa-content.component';

describe('UsaContentComponent', () => {
  let component: UsaContentComponent;
  let fixture: ComponentFixture<UsaContentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsaContentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsaContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
