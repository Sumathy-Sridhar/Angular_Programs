import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usa-content',
  templateUrl: './usa-content.component.html',
  styleUrls: ['./usa-content.component.css']
})
export class UsaContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
