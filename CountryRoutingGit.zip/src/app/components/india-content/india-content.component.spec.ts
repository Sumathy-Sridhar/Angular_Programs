import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IndiaContentComponent } from './india-content.component';

describe('IndiaContentComponent', () => {
  let component: IndiaContentComponent;
  let fixture: ComponentFixture<IndiaContentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IndiaContentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IndiaContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
