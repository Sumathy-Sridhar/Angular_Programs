import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-india-content',
  templateUrl: './india-content.component.html',
  styleUrls: ['./india-content.component.css']
})
export class IndiaContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
