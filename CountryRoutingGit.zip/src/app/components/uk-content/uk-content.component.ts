import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uk-content',
  templateUrl: './uk-content.component.html',
  styleUrls: ['./uk-content.component.css']
})
export class UkContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
