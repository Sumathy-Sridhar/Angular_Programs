import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UkContentComponent } from './uk-content.component';

describe('UkContentComponent', () => {
  let component: UkContentComponent;
  let fixture: ComponentFixture<UkContentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UkContentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UkContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
