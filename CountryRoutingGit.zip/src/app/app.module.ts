import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { IndiaContentComponent } from './components/india-content/india-content.component';
import { UsaContentComponent } from './components/usa-content/usa-content.component';
import { UkContentComponent } from './components/uk-content/uk-content.component';

@NgModule({
  declarations: [
    AppComponent,
    IndiaContentComponent,
    UsaContentComponent,
    UkContentComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
 

}